import json
from src.api.main import app
from src.transliteration.gurmukhi_practical import GurmukhiPractical
from src.transliteration.gurmukhi_legacy import GurmukhiLegacy

def handler(event, context):
    try:
        # Log the incoming event
        print("Received event:", json.dumps(event))
        
        # Get the path
        path = event.get('path', '')
        print("Path:", path)
        
        # Common headers for CORS
        headers = {
            'Content-Type': 'application/json',
            'Access-Control-Allow-Origin': 'http://gurmukhitransliterator.com.s3-website-us-east-1.amazonaws.com',
            'Access-Control-Allow-Headers': 'Content-Type,X-Amz-Date,Authorization,X-Api-Key,X-Amz-Security-Token',
            'Access-Control-Allow-Methods': 'GET,POST,OPTIONS'
        }
        
        if path == '/legacy-characters':
            # Handle legacy-characters endpoint
            special_chars = set()
            
            # Add characters from SPECIAL_COMBINATIONS
            for combo in GurmukhiLegacy.SPECIAL_COMBINATIONS.keys():
                special_chars.update(combo)
            
            # Add characters from ANMOLLIPI_MAP
            for char in GurmukhiLegacy.ANMOLLIPI_MAP.keys():
                special_chars.add(char)
            
            # Add characters from SUBJOINED_MAP
            for char in GurmukhiLegacy.SUBJOINED_MAP.keys():
                special_chars.add(char)
            
            result = sorted(list(special_chars))
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'characters': result})
            }
        else:
            # Handle transliterate endpoint
            body = event.get('body', '{}')
            if isinstance(body, str):
                body = json.loads(body)
            
            text = body.get('text', '')
            result = GurmukhiPractical.to_practical(text)
            
            return {
                'statusCode': 200,
                'headers': headers,
                'body': json.dumps({'result': result})
            }
            
    except Exception as e:
        print("Error:", str(e))
        return {
            'statusCode': 500,
            'headers': headers,
            'body': json.dumps({'error': str(e)})
        }